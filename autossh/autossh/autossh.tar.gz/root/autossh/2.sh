#!/bin/bash
source 1.sh
echo $PATH
